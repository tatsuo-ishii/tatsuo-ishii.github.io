<?php
/**
 * PostgreSQL async query function test script.
 *
 * There are number of restrictions to make async query work.
 * Refer to libpq manual for details.
 *
 * pg_send_query does not Multiple query, however user
 * may retrive result separately.
 *
 * This script is for php binary. Disable output buffering
 * to see the difference.
 *
 * yasuo_ohgaki@yahoo.com
 */

/***** CONFIG ******/
$table = 'pgsql_async_func_test';  // Test table name to create
$numrec = 50000;                   // Number of records to create
$connstr = 'host=dev dbname=yohgaki user=yohgaki'; // Database to connect


/******** test funcitons ********/
function create_test_table($db) 
{
	global $table;	
	$sql="
SELECT
	a.attname,
	a.attnum,
	t.typname,
	a.attlen,
	a.atttypmod,
	a.attnotNULL,
	a.atthasdef
FROM
	pg_class as c,
	pg_attribute a,
	pg_type t
WHERE
	a.attnum > 0 AND
	a.attrelid = c.oid AND
	c.relname = '$table' AND
	a.atttypid = t.oid
ORDER BY
	a.attnum;

";
	$res = pg_exec($db,$sql);
	if (!pg_numrows($res)) {
		echo "Creating test table..\n";
		$sql = "CREATE TABLE $table (str text);";
		if (pg_exec($db,$sql) !== FALSE)
		{
			$val = 'Async query can improve application performance significantly. Please test and report any failure to yasuo_ohgaki@yahoo.com. There are cases that async query does not work as expected. Refer to libpq manual for details. I also implemented functions that I need pg_status() - returns connection stauts and pg_reset() - reset connection. (Useful when connection is broken for some reason - most likely backend is died)';
			for ($i=0; $i < 50000; $i++) {
				pg_exec($db,"INSERT INTO $table (str) VALUES ('$val');");
				if (!($i % 100)) {
					echo '.';
				}
			}
			echo "\n";
			$val = '     XYZ         '; // To make select actually return a row. 'XYZ' is search pattern.
			pg_exec($db,"INSERT INTO $table (str) VALUES ('$val');");
		}
		else {
			die("ERR: Failed creating test table.".pg_errormessage()."\n\n\n\n\n\n");
		}
	}
	else {
		echo "Test table exists\n";
	}
}

function check_status($db) 
{
	$status = pg_status($db);

	switch ($status) {
		case PGSQL_CONNECTION_OK:
			echo "Status: Connection is ready\n";
			break;
		case PGSQL_CONNECTION_BAD:
			echo "Status: Connectin is BAD\n";
			break;
		default:
			echo "Status: Unkonwn ($status)\n";
			break;
	}
	return $status;
}

function execute_query($db,$async = TRUE) 
{
	global $table;
	echo "Executing query..";
	$ret = null;
	$sql = "
SELECT * FROM $table WHERE str like '%XYZ%';
";
	if ($async) {
		return pg_send_query($db,$sql);
	}
	if (!($ret = pg_exec($db,$sql))) {
		echo "Query failed..\n";
	}
	return $ret;
}

function check_result($result) 
{
	if (!$result){
		echo "Check result: NG\n";
		return false;
	}
	echo "Check result: Ok\n";
	return true;
}


function dump_result($result) 
{
	if (check_result($result)) {
		$cnt = pg_numrows($result);
		for($i=0; $i < $cnt; $i++) {
			$rec = pg_fetch_array($result,$i,PGSQL_ASSOC);
			print_r($rec);
		}
	}
}

/********  MAIN **********/
$db = pg_connect($connstr);
create_test_table($db);

////////////// nonblocked query /////////////////////
echo "\n *** non-blocking qeury *** \n\n";

check_status($db);
execute_query($db);
while (pg_is_busy($db)) 
{
	echo ".";
	sleep(1);
}
echo "\n";

$result = pg_get_result($db);
dump_result($result);

// RESET connection

if (!pg_reset($db)) 
{
	die("Failed to reset connection");
}

/////////////// blocked query /////////////////////////
echo "\n *** blocking qeury *** \n\n";

check_status($db);
$result = execute_query($db, false);
echo "\n";

dump_result($result);

?>












