/* 
 * tkWStr.c --
 *
 *	This file contains a collection of procedures that are used
 *	to handle the wide strings.
 *
 * Copyright 1988,1993 Software Research Associates, Inc.
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted, provided
 * that the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Software Research Associates not be
 * used in advertising or publicity pertaining to distribution of the
 * software without specific, written prior permission.  Software Research
 * Associates makes no representations about the suitability of this software
 * for any purpose.  It is provided "as is" without express or implied
 * warranty.
 */

#ifndef lint
static char rcsid[] = "$Header: /ext/cvsroot/tk/generic/tkWStr.c,v 1.3 1996/07/05 02:14:02 nisinaka Exp $";
#endif

#ifdef KANJI

#include "tkPort.h"
#include "tkInt.h"

/*
 * One of the following data structures exists for each font set that is
 * currently active.  The structure is indexed with two hash tables,
 * one based on font name and one based on XFontStruct address.
 */

typedef struct {
    XWSFontSet *fontset;
    int refCount;
    Tcl_HashEntry *fontsetHashPtr;
} TkFontSet;

/*
 * Hash table for asciiFont & kanjiFont -> TkFontSet mapping,
 * and key structure used to index into that table:
 */

static Tcl_HashTable fontsetTable;
typedef struct {
    XFontStruct *asciiFontPtr;
    XFontStruct *kanjiFontPtr;
} FontSetKey;

/*
 * Hash table for font struct -> TkFont mapping. This table is
 * indexed by the XFontStruct address.
 */

static Tcl_HashTable fs_idTable;

static int fs_initialized = 0;	/* 0 means static structures haven't been
				 * initialized yet. */


/*
 * One of the following data structures exists for each GCSet that is
 * currently active.  The structure is indexed with two hash tables,
 * one based on font name and one based on XFontStruct address.
 */

typedef struct {
    XWSGC gcset;		/* GCSet */
    int refCount;		/* Number of active uses of gc. */
    Tcl_HashEntry *gcsetHashPtr;/* Entry in gcsetTable (needed when deleting
				 * this structure). */
} TkGCSet;

/*
 * Hash table to map from a GCSet's values to a TkGCSet structure describing
 * a GCSet with those values (used by Tk_GetGCSet).
 */

static Tcl_HashTable gcsetTable;
typedef struct {
    XWSFontSet *fontset;	/* Desired values for XWSFontSet. */
    GC asciiGC;			/* Desired values for GC with ascii font. */
    GC kanjiGC;			/* Desired values for GC with kanji font. */
} GCSetKey;

/*
 * Hash table for GCSet -> TkGCSet mapping. This table is indexed by the 
 * GCSet identifier, and is used by Tk_FreeGCSet.
 */

static Tcl_HashTable gs_idTable;

static int gs_initialized = 0;	/* 0 means static structures haven't been
				 * initialized yet. */

/*
 * One of the following data structures exists for each font set that is
 * currently active.  The structure is indexed with two hash tables,
 * one based on font name and one based on XFontStruct address.
 */

typedef struct {
    int kanjiCode;
    char *str;
    wchar *wstr;
    int refCount;
    Tcl_HashEntry *wstrHashPtr;
} TkWStr;

/*
 * Hash table to map from a wide string's values to a TkWStr structure
 * describing a wide string with those values (used by Tk_GetWStr).
 */

static Tcl_HashTable wstrTable;

/*
 * Hash table for wchar -> TkWStr mapping. This table is indexed by the 
 * wchar identifier, and is used by Tk_FreeWStr.
 */

static Tcl_HashTable ws_idTable;

static int ws_initialized = 0;	/* 0 means static structures haven't been
				 * initialized yet. */

/*
 * Trivial yet useful macros.
 */
#define MIN(a, b)	((a) > (b) ? (b) : (a))
#define MAX(a, b)	((a) > (b) ? (a) : (b))

/*
 * Forward declarations for procedures defined in this file:
 */

static void	FontSetInit _ANSI_ARGS_((void));
static void	GCSetInit _ANSI_ARGS_((void));
static void	WStrInit _ANSI_ARGS_((void));
static int	wsdrawstring _ANSI_ARGS_ ((Display *display,
		    Drawable drawable, XWSGC gcset,
		    int x, int y, wchar *wstring, int length));
static int	flushstr _ANSI_ARGS_ ((Display *display,
		    Drawable drawable,  FontEnt *fe,
		    int x, int y,
		    XChar2b *cp0, XChar2b *cp1));

/*
 *----------------------------------------------------------------------
 *
 * Tk_GetFontSet --
 *
 *	Given two XFontStruct *, asciiFontPtr & kanjiFontPtr, map them
 *	to an XWSFontSet describing the font set.
 *
 * Results:
 *	The return value is normally a pointer to the font set description
 *	for the desired font set.
 *
 * Side effects:
 *	The font set is added to an internal database with a reference count.
 *	For each call to this procedure, there should eventually be a call
 *	to Tk_FreeFontSet, so that the database is cleaned up when fonts
 *	aren't in use anymore.
 *
 *----------------------------------------------------------------------
 */
XWSFontSet *
Tk_GetFontSet(asciiFontPtr, kanjiFontPtr)
     XFontStruct *asciiFontPtr;
     XFontStruct *kanjiFontPtr;
{
    FontSetKey key;
    Tcl_HashEntry *fontsetHashPtr, *idHashPtr;
    register TkFontSet *fontsetPtr;
    int new;
    

    if( !fs_initialized ) FontSetInit();

    /*
     * First, check to see if there's already a mapping for this font
     * set.
     */

    key.asciiFontPtr = asciiFontPtr;
    key.kanjiFontPtr = kanjiFontPtr;

    fontsetHashPtr = Tcl_CreateHashEntry(&fontsetTable, (char *)&key, &new);
    if( !new ) {
	fontsetPtr = (TkFontSet *)Tcl_GetHashValue(fontsetHashPtr);
	fontsetPtr->refCount++;
	return( fontsetPtr->fontset );
    }

    /*
     * The font set isn't currently known.  Map from the asciiFont & 
     * kanjiFont to a font set, and add a new structure to the database.
     */

    fontsetPtr = (TkFontSet *)ckalloc(sizeof(TkFontSet));
    fontsetPtr->fontset = (XWSFontSet *)ckalloc(sizeof(XWSFontSet));
    fontsetPtr->fontset->asciiFont = asciiFontPtr;
    fontsetPtr->fontset->kanjiFont = kanjiFontPtr;
    fontsetPtr->fontset->min_bounds.width
      = MIN(asciiFontPtr->min_bounds.width, kanjiFontPtr->min_bounds.width);
    fontsetPtr->fontset->min_bounds.rbearing
      = MIN(asciiFontPtr->min_bounds.rbearing, kanjiFontPtr->min_bounds.rbearing);
    fontsetPtr->fontset->max_bounds.descent
      = MAX(asciiFontPtr->max_bounds.descent, kanjiFontPtr->max_bounds.descent);
    fontsetPtr->fontset->max_bounds.lbearing
      = MAX(asciiFontPtr->max_bounds.lbearing, kanjiFontPtr->max_bounds.lbearing);
    fontsetPtr->fontset->max_bounds.rbearing
      = MAX(asciiFontPtr->max_bounds.rbearing, kanjiFontPtr->max_bounds.rbearing);
    fontsetPtr->fontset->ascent
      = MAX(asciiFontPtr->ascent, kanjiFontPtr->ascent);
    fontsetPtr->fontset->descent
      = MAX(asciiFontPtr->descent, kanjiFontPtr->descent);
    fontsetPtr->refCount = 1;
    fontsetPtr->fontsetHashPtr = fontsetHashPtr;
    idHashPtr = Tcl_CreateHashEntry(&fs_idTable, (char *)fontsetPtr->fontset, &new);
    if( !new ) {
	panic("FontSet already registered in Tk_GetFontSet");
    }
    Tcl_SetHashValue(fontsetHashPtr, fontsetPtr);
    Tcl_SetHashValue(idHashPtr, fontsetPtr);

    return( fontsetPtr->fontset );
}

/*
 *----------------------------------------------------------------------
 *
 * Tk_FreeFontSet --
 *
 *	This procedure is called to release a font set allocated by
 *	Tk_GetFontSet.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The reference count associated with font set is decremented,
 *	and the font set is officially deallocated if no-one is using
 *	it anymore.
 *
 *----------------------------------------------------------------------
 */
void
Tk_FreeFontSet(fontset)
     XWSFontSet *fontset;
{
    Tcl_HashEntry *idHashPtr;
    register TkFontSet *fontsetPtr;

    if( !fs_initialized ) panic("Tk_FreeFontSet called before Tk_GetFontSet");

    idHashPtr = Tcl_FindHashEntry(&fs_idTable, (char *)fontset);
    if( idHashPtr == NULL ) {
	panic("Tk_FreeFontSet received unknown fontset argument");
    }
    fontsetPtr = (TkFontSet *)Tcl_GetHashValue(idHashPtr);
    fontsetPtr->refCount--;
    if( fontsetPtr->refCount == 0 ) {
	ckfree((char *)fontsetPtr->fontset);
	Tcl_DeleteHashEntry(fontsetPtr->fontsetHashPtr);
	Tcl_DeleteHashEntry(idHashPtr);
	ckfree((char *)fontsetPtr);
    }
}

/*
 *----------------------------------------------------------------------
 *
 * FontSetInit --
 *
 *	Initialize the structures used for FontSet management.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	Read the code.
 *
 *----------------------------------------------------------------------
 */

static void
FontSetInit()
{
    fs_initialized = 1;
    Tcl_InitHashTable(&fontsetTable, sizeof(FontSetKey)/sizeof(int));
    Tcl_InitHashTable(&fs_idTable, TCL_ONE_WORD_KEYS);
}

/*
 *----------------------------------------------------------------------
 *
 * Tk_GetGCSet --
 *
 *	Given a desired set of values for a graphics context, find
 *	a read-only GCSet with the desired values.
 *
 * Results:
 *	The return value is the XWSGC which describes GCSet.
 *	The caller should never modify this GCSet, and should
 *	call Tk_FreeGCSet when the GCSet is no longer needed.
 *
 * Side effects:
 *	The GCSet is added to an internal database with a reference count.
 *	For each call to this procedure, there should eventually be a call
 *	to Tk_FreeGCSet, so that the database can be cleaned up when
 *	GCSet's aren't needed anymore.
 *
 *----------------------------------------------------------------------
 */
XWSGC
Tk_GetGCSet(tkwin, valueMask, valuePtr, fontset)
     Tk_Window tkwin;
     register unsigned long valueMask;
     register XGCValues *valuePtr;
     register XWSFontSet *fontset;
{
    GCSetKey key;
    Tcl_HashEntry *gcsetHashPtr, *idHashPtr;
    register TkGCSet *gcsetPtr;
    XGCValues value;
    int new;

    if( !gs_initialized ) GCSetInit();

    /*
     * First, check to see if there's already a GCSet that will work
     * for this request (exact matches only, sorry).
     */

    key.fontset = fontset;
    value = *valuePtr;
    valueMask |= GCFont;
    value.font = fontset->asciiFont->fid;
    key.asciiGC = Tk_GetGC(tkwin, valueMask, &value);
    value.font = fontset->kanjiFont->fid;
    key.kanjiGC = Tk_GetGC(tkwin, valueMask, &value);

    gcsetHashPtr = Tcl_CreateHashEntry(&gcsetTable, (char *)&key, &new);
    if( !new ) {
	gcsetPtr = (TkGCSet *)Tcl_GetHashValue(gcsetHashPtr);
	gcsetPtr->refCount++;
	return( gcsetPtr->gcset );
    }

    /*
     * No GCSet is currently available for this set of values.  Allocate a
     * new GC and add a new structure to the database.
     */

    gcsetPtr = (TkGCSet *)ckalloc(sizeof(TkGCSet));
    gcsetPtr->gcset = (XWSGC )ckalloc(sizeof(XWSGCSet));
    gcsetPtr->gcset->fe[0].font = fontset->asciiFont;
    gcsetPtr->gcset->fe[0].gc   = key.asciiGC;
    gcsetPtr->gcset->fe[0].flag = TK_GCCREAT
                                  | ( IS2B(fontset->asciiFont) ? TK_TWOB : 0 );
    gcsetPtr->gcset->fe[1].font = fontset->kanjiFont;
    gcsetPtr->gcset->fe[1].gc   = key.kanjiGC;
    gcsetPtr->gcset->fe[1].flag = TK_GCCREAT
                                  | ( IS2B(fontset->kanjiFont) ? TK_TWOB : 0 );
    if (fontset->kanjiFont->min_byte1 > 0x80) {
	/* GR encoding -- all the character codes have their 8th bit on */
	gcsetPtr->gcset->fe[1].flag |= TK_GRMAPPING;
    }
    gcsetPtr->gcset->fe[2].font = NULL;
    gcsetPtr->gcset->fe[3].font = NULL;
    gcsetPtr->refCount = 1;
    gcsetPtr->gcsetHashPtr = gcsetHashPtr;
    idHashPtr = Tcl_CreateHashEntry(&gs_idTable, (char *)gcsetPtr->gcset, &new);
    if( !new ) {
	panic("GCSet already registered in Tk_GetGCSet");
    }
    Tcl_SetHashValue(gcsetHashPtr, gcsetPtr);
    Tcl_SetHashValue(idHashPtr, gcsetPtr);

    return( gcsetPtr->gcset );
}

/*
 *----------------------------------------------------------------------
 *
 * Tk_FreeGCSet --
 *
 *	This procedure is called to release a GCSet allocated by
 *	Tk_GetGCSet.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The reference count associated with gcset is decremented, and
 *	gcset is officially deallocated if no-one is using it anymore.
 *
 *----------------------------------------------------------------------
 */
void
Tk_FreeGCSet(display, gcset)
    Display *display;		/* Display for which gc was allocated. */
    XWSGC gcset;		/* Graphics context to be released. */
{
    Tcl_HashEntry *idHashPtr;
    register TkGCSet *gcsetPtr;

    if( !gs_initialized ) panic("Tk_FreeGC called before Tk_GetGC");

    idHashPtr = Tcl_FindHashEntry(&gs_idTable, (char *)gcset);
    if( idHashPtr == NULL ) {
	panic("Tk_FreeGCSet received unknown gcset argument");
    }
    gcsetPtr = (TkGCSet *)Tcl_GetHashValue(idHashPtr);
    gcsetPtr->refCount--;
    if( gcsetPtr->refCount == 0 ) {
	if( gcsetPtr->gcset->fe[0].flag & TK_GCCREAT ) {
	    Tk_FreeGC(display, gcsetPtr->gcset->fe[0].gc);
	}
	if( gcsetPtr->gcset->fe[1].flag & TK_GCCREAT ) {
	    Tk_FreeGC(display, gcsetPtr->gcset->fe[1].gc);
	}
	ckfree((char *)gcsetPtr->gcset);
	Tcl_DeleteHashEntry(gcsetPtr->gcsetHashPtr);
	Tcl_DeleteHashEntry(idHashPtr);
	ckfree((char *)gcsetPtr);
    }
}

/*
 *----------------------------------------------------------------------
 *
 * GCSetInit --
 *
 *	Initialize the structures used for GCSet management.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	Read the code.
 *
 *----------------------------------------------------------------------
 */

static void
GCSetInit()
{
    gs_initialized = 1;
    Tcl_InitHashTable(&gcsetTable, sizeof(GCSetKey)/sizeof(int));
    Tcl_InitHashTable(&gs_idTable, TCL_ONE_WORD_KEYS);
}

/*
 *----------------------------------------------------------------------
 *
 * Tk_GetWStr --
 *
 *	Given a string, map them to a wide string.
 *
 * Results:
 *	The return value is normally a pointer to the wide string.
 *
 * Side effects:
 *	The wide string is added to an internal database with a reference
 *	count.  For each call to this procedure, there should eventually
 *	be a call to Tk_FreeWStr, so that the database is cleaned up when
 *	wide strings aren't in use anymore.
 *
 *----------------------------------------------------------------------
 */
wchar *
Tk_GetWStr(interp, str)
     Tcl_Interp *interp;
     char *str;
{
    Tcl_HashEntry *wstrHashPtr;
    int new;
    TkWStr *wstrPtr;
    Tcl_HashEntry *idHashPtr;
    int kanjiCode;
    int length;

    if (!ws_initialized) WStrInit();

    /*
     * Get the kanji encoding information.
     */
    if (interp != NULL) {
	kanjiCode = Tcl_KanjiCode(interp);
    } else {
	(void) Tcl_KanjiString(NULL, str, &kanjiCode);
    }


    /*
     * First, check to see if there's already a mapping for this string.
     */

    wstrHashPtr = Tcl_CreateHashEntry(&wstrTable, str, &new);
    if (!new) {
	wstrPtr = (TkWStr *)Tcl_GetHashValue(wstrHashPtr);
	wstrPtr->refCount++;
	return wstrPtr->wstr;
    }

    /*
     * The string isn't currently known.  Map from the string to
     * a wide string, and add a new structure to the database.
     */

    wstrPtr = (TkWStr *) ckalloc(sizeof(TkWStr));
    wstrPtr->kanjiCode = kanjiCode;
    wstrPtr->str = ckalloc((unsigned)(strlen(str) + 1));
    strcpy(wstrPtr->str, str);
    length = Tcl_KanjiEncode(kanjiCode, str, NULL);
    wstrPtr->wstr = (wchar *) ckalloc((unsigned)(length + 1) * sizeof(wchar));
    (void) Tcl_KanjiEncode(kanjiCode, str, wstrPtr->wstr);
    wstrPtr->refCount = 1;
    wstrPtr->wstrHashPtr = wstrHashPtr;
    idHashPtr = Tcl_CreateHashEntry(&ws_idTable, (char *)wstrPtr->wstr, &new);
    if (!new) {
	panic("wstr already registered in Tk_GetWStr");
    }
    Tcl_SetHashValue(wstrHashPtr, wstrPtr);
    Tcl_SetHashValue(idHashPtr, wstrPtr);

    return wstrPtr->wstr;
}

/*
 *----------------------------------------------------------------------
 *
 * Tk_FreeWStr --
 *
 *	This procedure is called to release a wide string allocated
 *	by Tk_GetWStr.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The reference count associated with wstr is decremented, and
 *	wstr is officially deallocated if no-one is using it anymore.
 *
 *----------------------------------------------------------------------
 */
void
Tk_FreeWStr(wstr)
     wchar *wstr;
{
    Tcl_HashEntry *idHashPtr;
    register TkWStr *wstrPtr;

    if( !ws_initialized ) panic("Tk_FreeWStr called before Tk_GetWStr");

    idHashPtr = Tcl_FindHashEntry(&ws_idTable, (char *)wstr);
    if( idHashPtr == NULL ) {
	panic("Tk_FreeWStr received unknown wstr argument");
    }
    wstrPtr = (TkWStr *)Tcl_GetHashValue(idHashPtr);
    wstrPtr->refCount--;
    if( wstrPtr->refCount == 0 ) {
	ckfree((char *)wstrPtr->str);
	ckfree((char *)wstrPtr->wstr);
	Tcl_DeleteHashEntry(wstrPtr->wstrHashPtr);
	Tcl_DeleteHashEntry(idHashPtr);
	ckfree((char *)wstrPtr);
    }
}

/*
 *----------------------------------------------------------------------
 *
 * Tk_InsertWStr --
 *
 *	This procedure is called to modify the existing wide
 *	string by inserting characters.
 *
 * Results:
 *	The return value is a pointer to the wide string.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */
wchar *
Tk_InsertWStr(interp, orig, index, wstr)
     Tcl_Interp *interp;
     wchar *orig;
     int index;
     wchar *wstr;
{
    int origLen, wstrLen;
    wchar *newstr;
    register int kanjiCode = Tcl_KanjiCode(interp);
    char *str;
    int length, new;
    Tcl_HashEntry *wstrHashPtr;
    register TkWStr *wstrPtr;
    Tcl_HashEntry *idHashPtr;

    if (!ws_initialized) panic("Tk_InsertWStr called before Tk_GetWStr");

    origLen = Tcl_WStrlen(orig);
    wstrLen = Tcl_WStrlen(wstr);
    newstr = (wchar *) ckalloc((unsigned)(origLen + wstrLen + 1) * sizeof(wchar));
    Tcl_WStrncpy(newstr, orig, index);
    Tcl_WStrcpy(newstr+index, wstr);
    Tcl_WStrcpy(newstr+index+wstrLen, orig+index);

    /*
     * Check if there's already a mapping for this string.
     */
    length = Tcl_KanjiDecode(kanjiCode, newstr, NULL);
    str = (char *) ckalloc((unsigned)(length + 1));
    (void) Tcl_KanjiDecode(kanjiCode, newstr, str);

    wstrHashPtr = Tcl_CreateHashEntry(&wstrTable, str, &new);
    if (!new) {
	wstrPtr = (TkWStr *) Tcl_GetHashValue(wstrHashPtr);
	wstrPtr->refCount++;
	Tk_FreeWStr(orig);
	ckfree((char *) newstr);
	ckfree(str);
	return wstrPtr->wstr;
    }

    /*
     * The string isn't currently known.  Map from the string to
     * a wide string, and add a new structure to the database.
     */
    wstrPtr = (TkWStr *) ckalloc(sizeof(TkWStr));
    wstrPtr->kanjiCode = kanjiCode;
    wstrPtr->str = str;
    wstrPtr->wstr = newstr;
    wstrPtr->refCount = 1;
    wstrPtr->wstrHashPtr = wstrHashPtr;
    idHashPtr = Tcl_CreateHashEntry(&ws_idTable, (char *)wstrPtr->wstr, &new);
    if (!new) {
	panic("wstr already registered in Tk_InsertWStr");
    }
    Tcl_SetHashValue(wstrPtr->wstrHashPtr, wstrPtr);
    Tcl_SetHashValue(idHashPtr, wstrPtr);

    Tk_FreeWStr(orig);
    return wstrPtr->wstr;
}

/*
 *----------------------------------------------------------------------
 *
 * Tk_DeleteWStr --
 *
 *	This procedure is called to modify the existing wide
 *	string by deleting characters.
 *
 * Results:
 *	The return value is a pointer to the wide string.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */
wchar *
Tk_DeleteWStr(interp, orig, index, count)
     Tcl_Interp *interp;
     wchar *orig;
     int index;
     int count;
{
    int length;
    wchar *newstr;
    register int kanjiCode = Tcl_KanjiCode(interp);
    char *str;
    Tcl_HashEntry *wstrHashPtr;
    register TkWStr *wstrPtr;
    Tcl_HashEntry *idHashPtr;
    int new;

    if (!ws_initialized) panic("Tk_InsertWStr called before Tk_GetWStr");

    length = Tcl_WStrlen(orig);
    newstr = (wchar *) ckalloc((unsigned)(length - count + 1) * sizeof(wchar));
    Tcl_WStrncpy(newstr, orig, index);
    Tcl_WStrcpy(newstr+index, orig+index+count);

    /*
     * Check if there's already a mapping for this string.
     */
    length = Tcl_KanjiDecode(kanjiCode, newstr, NULL);
    str = (char *) ckalloc((unsigned)(length + 1));
    (void) Tcl_KanjiDecode(kanjiCode, newstr, str);

    wstrHashPtr = Tcl_CreateHashEntry(&wstrTable, str, &new);
    if (!new) {
	wstrPtr = (TkWStr *) Tcl_GetHashValue(wstrHashPtr);
	wstrPtr->refCount++;
	ckfree((char *) newstr);
	ckfree(str);
	Tk_FreeWStr(orig);
	return wstrPtr->wstr;
    }

    /*
     * The string isn't currently known.  Map from the string to
     * a wide string, and add a new structure to the database.
     */
    wstrPtr = (TkWStr *) ckalloc(sizeof(TkWStr));
    wstrPtr->kanjiCode = kanjiCode;
    wstrPtr->str = str;
    wstrPtr->wstr = newstr;
    wstrPtr->refCount = 1;
    wstrPtr->wstrHashPtr = wstrHashPtr;
    idHashPtr = Tcl_CreateHashEntry(&ws_idTable, (char *)wstrPtr->wstr, &new);
    if (!new) {
	panic("wstr already registered in Tk_DeleteWStr");
    }
    Tcl_SetHashValue(wstrPtr->wstrHashPtr, wstrPtr);
    Tcl_SetHashValue(idHashPtr, wstrPtr);

    Tk_FreeWStr(orig);
    return wstrPtr->wstr;
}

/*
 *--------------------------------------------------------------
 *
 * Tk_DecodeWStr --
 *
 *	Answer the original string of the wide string.
 *
 * Results:
 *	The return value is the original string of the wide string.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

char *
Tk_DecodeWStr(wstr)
     wchar *wstr;
{
    Tcl_HashEntry *idHashPtr;
    register TkWStr *wstrPtr;

    if (!ws_initialized) panic("Tk_DecodeWStr called before Tk_GetWStr");

    idHashPtr = Tcl_FindHashEntry(&ws_idTable, (char *)wstr);
    if( idHashPtr == NULL ) {
	panic("Tk_DecodeWStr received unknown wstr argument");
    }
    wstrPtr = (TkWStr *) Tcl_GetHashValue(idHashPtr);

    return wstrPtr->str;
}

/*
 *----------------------------------------------------------------------
 *
 * WStrInit --
 *
 *	Initialize the structures used for WStr management.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	Read the code.
 *
 *----------------------------------------------------------------------
 */

static void
WStrInit()
{
    ws_initialized = 1;
    Tcl_InitHashTable(&wstrTable, TCL_STRING_KEYS);
    Tcl_InitHashTable(&ws_idTable, TCL_ONE_WORD_KEYS);
}

/*
 *--------------------------------------------------------------
 *
 * TkWSDrawString --
 *
 *	Draw a wide string on the screen.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	Information gets drawn on the screen.
 *
 *--------------------------------------------------------------
 */

int
TkWSDrawString(display, drawable, gcset, x, y, wstring, length)
     Display *display;
     Drawable drawable;
     XWSGC gcset;
     int x, y;
     wchar *wstring;
     int length;
{
    return wsdrawstring(display, drawable, gcset, x, y, wstring, length);
}

/*
 *--------------------------------------------------------------
 *
 * TkWSTextWidth --
 *
 *	Get the width in pixels of the wide string.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

int
TkWSTextWidth(gcset, wstr, len)
     XWSGC gcset;
     wchar *wstr;
     int len;
{
#define bufsize	256
	XChar2b			buf[bufsize];
	XChar2b			*cp;
	XChar2b			*cpend = buf + bufsize;
	wchar			*wstr1 = wstr + len;
	int			c;
	int			width = 0;
	int			gmask, gset;
	FontEnt			*fe;
	int			gr_mapping;

	while( wstr < wstr1 ) {
	    gmask = *wstr & 0x8080;
	    gr_mapping = 0;

	    switch( gmask ) {
	      case G0MASK:
		gset = 0;
		break;
	      case G1MASK:
		gset = 1;
		break;
#ifdef ORIGINAL_XWSTR
	      case G2MASK:
		gset = 2;
		break;
	      case G3MASK:
		gset = 3;
		break;
#else /* to display every one byte character */
	      case G2MASK:
	      case G3MASK:
		gset = 0;
		gr_mapping = 1;
		break;
#endif /* ORIGINAL_XWSTR */
	    }

	    fe = &gcset->fe[gset];
	    gr_mapping |= fe->flag & TK_GRMAPPING;
	    cp = buf;

	    if( fe->font == NULL ) {
		while( wstr < wstr1 && (*wstr & 0x8080) == gmask ) wstr++;
		continue;
	    }

	    while( wstr < wstr1 && ((c = *wstr) & 0x8080) == gmask ) {
		if( cp >= cpend - 1) {
		    /* flush */
		    width += XTextWidth16(fe->font, buf, cp - buf);
		    cp = buf;
		}
		cp->byte1 = (c >> 8) & 0x7f;
		cp->byte2 = c & 0x7f;
		if (gr_mapping) {
		    if (cp->byte1 != 0) cp->byte1 |= 0x80;
		    cp->byte2 |= 0x80;
		}
		cp++;
		wstr++;
	    }

	    if( cp == buf ) continue;

	    /* flush */
	    width += XTextWidth16(fe->font, buf, cp - buf);
	}

	return width;
}

/*
 *--------------------------------------------------------------
 *
 * TkWSTextExtents --
 *
 *	Get string and font metrics of the wide string.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

void
TkWSTextExtents(gcset, wstr, len, ascent, descent, overall)
     XWSGC gcset;
     wchar *wstr;
     int len;
     int *ascent, *descent;
     XCharStruct *overall;
{
#define bufsize	256
#define INITIAL_LBEARING 9999
    XChar2b		buf[bufsize];
    XChar2b		*cp;
    XChar2b		*cpend = buf + bufsize;
    wchar		*wstr1 = wstr + len;
    int			c;
    int			gmask, gset;
    FontEnt		*fe;
    int			gr_mapping;
    int			dir, as, ds;
    XCharStruct		oa;

    *ascent = *descent = 0;
    memset((VOID *) overall, 0, sizeof(XCharStruct));
    overall->lbearing = INITIAL_LBEARING;

    while( wstr < wstr1 ) {
	gmask = *wstr & 0x8080;
	gr_mapping = 0;

	switch( gmask ) {
	  case G0MASK:
	    gset = 0;
	    break;
	  case G1MASK:
	    gset = 1;
	    break;
#ifdef ORIGINAL_XWSTR
	  case G2MASK:
	    gset = 2;
	    break;
	  case G3MASK:
	    gset = 3;
	    break;
#else /* to display every one byte character */
	  case G2MASK:
	  case G3MASK:
	    gset = 0;
	    gr_mapping = 1;
	    break;
#endif /* ORIGINAL_XWSTR */
	}

	fe = &gcset->fe[gset];
	gr_mapping |= fe->flag & TK_GRMAPPING;
	cp = buf;

	if( fe->font == NULL ) {
	    while( wstr < wstr1 && (*wstr & 0x8080) == gmask ) wstr++;
	    continue;
	}

	while( wstr < wstr1 && ((c = *wstr) & 0x8080) == gmask ) {
	    if( cp >= cpend - 1 ) {
		/* flush */
		XTextExtents16(fe->font, buf, cp - buf,
			       &dir, &as, &ds, &oa);
		cp = buf;
		*ascent = MAX(*ascent, as);
		*descent = MAX(*descent, ds);
		overall->lbearing = MIN(overall->lbearing,
					overall->width + oa.lbearing);
		overall->rbearing = MAX(overall->rbearing,
					overall->width + oa.rbearing);
		overall->width += oa.width;
		overall->ascent = MAX(overall->ascent, oa.ascent);
		overall->descent = MAX(overall->descent, oa.descent);
	    }
	    cp->byte1 = (c >> 8) & 0x7f;
	    cp->byte2 = c & 0x7f;
	    if (gr_mapping) {
		if (cp->byte1 != 0) cp->byte1 |= 0x80;
		cp->byte2 |= 0x80;
	    }
	    cp++;
	    wstr++;
	}

	if( cp == buf ) continue;

	/* flush */
	XTextExtents16(fe->font, buf, cp - buf, &dir, &as, &ds, &oa);

	*ascent = MAX(*ascent, as);
	*descent = MAX(*descent, ds);
	overall->lbearing = MIN(overall->lbearing,
				overall->width + oa.lbearing);
	overall->rbearing = MAX(overall->rbearing,
				overall->width + oa.rbearing);
	overall->width += oa.width;
	overall->ascent = MAX(overall->ascent, oa.ascent);
	overall->descent = MAX(overall->descent, oa.descent);
    }
    if( overall->lbearing == INITIAL_LBEARING ) {
        overall->lbearing = 0;
    }
#undef INITIAL_LBEARING
}

static int
wsdrawstring(display, drawable, gcset, x, y, wstr, len)
     Display *display;
     Drawable drawable;
     XWSGC gcset;
     int x, y;
     wchar *wstr;
     int len;
{
#define bufsize	256
    XChar2b		buf[bufsize];
    XChar2b		*cp;
    XChar2b		*cpend = buf + bufsize;
    wchar		*wstr1 = wstr + len;
    int			c;
    int			sx = x;
    int			gmask, gset;
    FontEnt		*fe;
    int			gr_mapping;

    while( wstr < wstr1 ) {
	gmask = *wstr & 0x8080;
	gr_mapping = 0;

	switch( gmask ) {
	  case G0MASK:
	    gset = 0;
	    break;
	  case G1MASK:
	    gset = 1;
	    break;
#ifdef ORIGINAL_XWSTR
	  case G2MASK:
	    gset = 2;
	    break;
	  case G3MASK:
	    gset = 3;
	    break;
#else /* to display every one byte character */
	  case G2MASK:
	  case G3MASK:
	    gset = 0;
	    gr_mapping = 1;
	    break;
#endif /* ORIGINAL_XWSTR */
	}

	fe = &gcset->fe[gset];
	gr_mapping |= fe->flag & TK_GRMAPPING;
	cp = buf;

	if( fe->font == NULL ) {
	    while( wstr < wstr1 && (*wstr & 0x8080) == gmask ) wstr++;
	    continue;
	}
	while( wstr < wstr1 && ((c = *wstr) & 0x8080) == gmask ) {
	    if( cp >= cpend - 1 ) {
		/* flush */
		x += flushstr(display, drawable, fe, x, y, buf, cp);
		cp = buf;
	    }
	    cp->byte1 = (c >> 8) & 0x7f;
	    cp->byte2 = c & 0x7f;
	    if (gr_mapping) {
		if (cp->byte1 != 0) cp->byte1 |= 0x80;
		cp->byte2 |= 0x80;
	    }
	    cp++;
	    wstr++;
	}
	/* flush */
	x += flushstr(display, drawable, fe, x, y, buf, cp);
	cp = buf;
    }

    return x - sx;
}

static int
flushstr(display, drawable, fe, x, y, cp0, cp1)
     Display *display;
     Drawable drawable;
     FontEnt *fe;
     int x, y;
     XChar2b *cp0, *cp1;
{
    if( cp0 >= cp1 || fe->gc == NULL ) return 0;

    XDrawString16(display, drawable, fe->gc, x, y, cp0, cp1 - cp0);
    return XTextWidth16(fe->font, cp0, cp1 - cp0);
}

#endif /* KANJI */
