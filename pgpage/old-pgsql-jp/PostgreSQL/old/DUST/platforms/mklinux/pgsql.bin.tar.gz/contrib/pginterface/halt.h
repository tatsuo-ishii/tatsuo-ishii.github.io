/*
** halt.h
**
*/

void halt();

