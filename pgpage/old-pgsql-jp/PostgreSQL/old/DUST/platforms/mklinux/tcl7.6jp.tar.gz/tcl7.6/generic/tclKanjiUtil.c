/* 
 * tclKanjiUtil.c --
 *
 *	This file contains utility procedures that are used by many Tcl
 *	commands.
 *
 * Copyright (c) 1988-1995 Software Research Associates, Inc.
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted, provided
 * that the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Software Research Associates not be
 * used in advertising or publicity pertaining to distribution of the
 * software without specific, written prior permission.  Software Research
 * Associates makes no representations about the suitability of this software
 * for any purpose.  It is provided "as is" without express or implied
 * warranty.
 */

#ifndef lint
static char rcsid[] = "$Header: /ext/cvsroot/tcl/generic/tclKanjiUtil.c,v 1.3 1996/07/05 02:12:27 nisinaka Exp $";
#endif

#ifdef KANJI

#include "tclInt.h"
#include "tclPort.h"

/*
 * If C_LOCALE_SPECIAL is defined, C locale is treated specially.
 * When the locale is C, the automatic kanji encoding detection
 * feature is disabled, so that any string is recognized as a normal
 * (ISO Latin-1) string.
 * This makes Japanized Tcl to behave just like the original Tcl.
 */
#define C_LOCALE_SPECIAL

/*
 * For setlocale() call.
 */
#ifdef HAVE_SETLOCALE
#include <locale.h>
#endif

/*
 * This array holds the printable kanji code name corresponding to
 * the kanji code defined in tcl.h.
 */

char *Tcl_KanjiCodeStr[] = { "JIS", "SJIS", "EUC", "ANY" };

#ifdef C_LOCALE_SPECIAL
/*
 * This variable indicates whether some special Kanji related feature
 * is disabled nor not.
 */
static int	noKanjiFeature = 0;
#endif /* C_LOCALE_SPECIAL */

/*
 * Function prototypes for local procedures in this file:
 */
static int		EncodingDetection _ANSI_ARGS_((Tcl_Interp *interp,
			    char *string));

#define T_ASCII	0
#define T_KANJI	1
#define T_KANA	2

/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiEncode --
 *
 *	Encode kanji string to wide string.
 *
 * Results:
 *	Number of the encoded characters. (Not bytes)
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiEncode(kanjiCode, ks, ws)
     int kanjiCode;
     unsigned char *ks;
     wchar *ws;
{
    switch (kanjiCode) {
      case TCL_JIS:
	return Tcl_EncodeJIS(ks, ws);
      case TCL_SJIS:
	return Tcl_EncodeSJIS(ks, ws);
      case TCL_EUC:
	return Tcl_EncodeEUC(ks, ws);
      case TCL_ANY:
	return Tcl_EncodeANY(ks, ws);
      default:
	panic("Tcl_KanjiEncode: Unknown kanjiCode.");
    }
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiDecode --
 *
 *	Decode kanji string to wide string.
 *
 * Results:
 *	Number of the encoded characters. (Not bytes)
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiDecode(kanjiCode, ws, ks)
     int kanjiCode;
     wchar *ws;
     unsigned char *ks;
{
    switch (kanjiCode) {
      case TCL_JIS:
	return Tcl_DecodeJIS(ws, ks);
      case TCL_SJIS:
	return Tcl_DecodeSJIS(ws, ks);
      case TCL_EUC:
	return Tcl_DecodeEUC(ws, ks);
      case TCL_ANY:
	return Tcl_DecodeANY(ws, ks);
      default:
	panic("Tcl_KanjiDecode: Unknown kanjiCode.");
    }
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_EncodeJIS --
 *
 *	Encode JIS kanji string to wide string.
 *
 * Results:
 *	Number of the encoded characters. (Not bytes)
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_EncodeJIS(js, ws)
     unsigned char *js;
     wchar *ws;
{
    int	c, c1;
    int	kanji = T_ASCII;
    int	n = 0;

    while( c = *js++ ) {
	if( c == '\033' ) {
	    if( !strncmp(js, "$B", 2) || !strncmp(js, "$@", 2)) {
		kanji = T_KANJI;
		js += 2;
	    } else if( !strncmp(js, "(J", 2) || !strncmp(js, "(B", 2) ) {
		kanji = T_ASCII;
		js += 2;
	    } else if( !strncmp(js, "(I", 2) ) {
		kanji = T_KANA;
		js += 2;
	    } else {
		if( ws ) *ws++ = c;
		n++;
	    }
	} else if( kanji == T_KANJI ) {
	    c1 = *js++;
	    if( c1 == '\0' ) break;
	    if( ws ) *ws++ = (c << 8) | c1 | 0x8080;
	    n++;
	} else {
	    if( ws ) *ws++ = c | ((kanji == T_KANA) ? 0x80 : 0);
	    n++;
	}
    }
    if( ws ) *ws = 0;

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DecodeJIS --
 *
 *	Decode wide string to JIS kanji string.
 *
 * Results:
 *	Bytes of the decoded kanji string.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_DecodeJIS(ws, js)
     wchar *ws;
     unsigned char *js;
{
    int	c;
    int	kanji = T_ASCII;
    int	n = 0;

    while( c = *ws++ ) {
	switch( c & 0x8080 ) {
	  case 0:
	    if( kanji != T_ASCII ) {
		if( js ) {
		    *js++ = '\033';
		    *js++ = '(';
		    *js++ = 'B';
		}
		n += 3;
	    }
	    if( js ) *js++ = c & 0x7f;
	    n++;
	    kanji = T_ASCII;
	    break;
	  case 0x80:
	    if( kanji != T_KANA ) {
		if( js ) {
		    *js++ = '\033';
		    *js++ = '(';
		    *js++ = 'I';
		}
		n += 3;
	    }
	    if( js ) *js++ = c & 0x7f;
	    n++;
	    kanji = T_KANA;
	    break;
	  case 0x8080:
	    if( kanji != T_KANJI ) {
		if( js ) {
		    *js++ = '\033';
		    *js++ = '$';
		    *js++ = 'B';
		}
		n += 3;
	    }
	    if( js ) {
		*js++ = (c >> 8) & 0x7f;
		*js++ = c & 0x7f;
	    }
	    n += 2;
	    kanji = T_KANJI;
	    break;
	}
    }
    if( kanji != T_ASCII ) {
	if( js ) {
	    *js++ = '\033';
	    *js++ = '(';
	    *js++ = 'B';
	}
	n += 3;
    }
    if( js ) *js = '\0';

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_EncodeSJIS --
 *
 *	Encode SJIS kanji string to wide string.
 *
 * Results:
 *	Number of the encoded characters. (Not bytes)
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

#define IS_SJIS(c) (((c) >= 0x81 && (c) <= 0x9f) || ((c) >= 0xe0 && (c) <= 0xfc))

int
Tcl_EncodeSJIS(ss, ws)
     unsigned char *ss;
     wchar *ws;
{
    int	c, c1;
    int	n = 0;

    while( c = *ss++ ) {
	if( IS_SJIS(c) ) {
	    c1 = *ss++;
	    c -= (c>=0xa0) ? 0xc1 : 0x81;
	    if( ws ) {
		if( c1 >= 0x9f ) {
		    *ws++ = ((c<<9) + 0x2200 + c1 - 0x7e) | 0x8080;
		} else {
		    *ws++ = ((c<<9) + 0x2100 + c1
			     - ((c1<=0x7e) ? 0x1f : 0x20)) | 0x8080;
		}
	    }
	    n++;
	} else {
	    if( ws ) *ws++ = c;
	    n++;
	}
    }
    if( ws ) *ws = 0;

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DecodeSJIS --
 *
 *	Decode wide string to SJIS kanji string.
 *
 * Results:
 *	Bytes of the decoded kanji string.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_DecodeSJIS(ws, ss)
     wchar *ws;
     unsigned char *ss;
{
    int	c1, c2;
    int	n = 0;

    while( c1 = *ws++ ) {
	switch( c1 & 0x8080 ) {
	  case 0:
	  case 0x80:
	    if( ss ) *ss++ = c1 & 0xff;
	    n++;
	    break;
	  case 0x8080:
	    c2 = c1 & 0x7f;
	    c1 = (c1 >> 8) & 0x7f;
	    if( ss ) {
		*ss++ = (c1 - 0x21) / 2 + ((c1 <= 0x5e) ? 0x81 : 0xc1);
		if( c1 & 1 ) {	/* odd */
		    *ss++ = c2 + ((c2 <= 0x5f) ? 0x1f : 0x20);
		} else {
		    *ss++ = c2 + 0x7e;
		}
	    }
	    n += 2;
	    break;
	}
    }
    if( ss ) *ss = '\0';

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_EncodeEUC --
 *
 *	Encode EUC kanji string to wide string.
 *
 * Results:
 *	Number of the encoded characters. (Not bytes)
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_EncodeEUC(es, ws)
     unsigned char *es;
     wchar *ws;
{
    int	c;
    int	n = 0;

    while( c = *es++ ) {
	if( c == 0x8e ) {	/* SS2 */
	    if( ws ) *ws++ = *es | 0x80;
	    es++;
	    n++;
	} else if( c == 0x8f ) {	/* SS3 */
	    c = *es++;
	    if( ws ) *ws++ = (c << 8) | (*es & 0x7f) | 0x8000;
	    es++;
	    n++;
	} else if( c & 0x80 ) {
	    if( ws ) *ws++ = (c << 8) | *es | 0x8080;
	    es++;
	    n++;
	} else {
	    if( ws ) *ws++ = c;
	    n++;
	}
    }
    if( ws ) *ws = 0;

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DecodeEUC --
 *
 *	Decode wide string to EUC kanji string.
 *
 * Results:
 *	Bytes of the decoded kanji string.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_DecodeEUC(ws, es)
     wchar *ws;
     unsigned char *es;
{
    int	c;
    int	n = 0;

    while( c = *ws++ ) {
	switch( c & 0x8080 ) {
	  case 0:
	    if( es ) *es++ = c & 0x7f;
	    n++;
	    break;
	  case 0x80:
	    if( es ) {
		*es++ = 0x8e;	/* SS2 */
		*es++ = c & 0xff;
	    }
	    n += 2;
	    break;
	  case 0x8000:
	    if( es ) {
		*es++ = 0x8f;	/* SS3 */
		*es++ = (c >> 8) | 0x80;
		*es++ = (c & 0xff) | 0x80;
	    }
	    n += 3;
	    break;
	  case 0x8080:
	    if( es ) {
		*es++ = c >> 8;
		*es++ = c & 0xff;
	    }
	    n += 2;
	    break;
	}
    }
    if( es ) *es = '\0';

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_EncodeANY --
 *
 *	Encode ANY kanji string to wide string. (as ascii string)
 *
 * Results:
 *	Number of the encoded characters. (Not bytes)
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_EncodeANY(as, ws)
     unsigned char *as;
     wchar *ws;
{
    int c;
    int	n = 0;

    while( c = *as++ ) {
	if( ws ) *ws++ = c;
	n++;
    }
    if( ws ) *ws = 0;

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DecodeANY --
 *
 *	Decode wide string to ANY kanji string. (as ascii string)
 *
 * Results:
 *	Bytes of the decoded kanji string.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_DecodeANY(ws, as)
     wchar *ws;
     unsigned char *as;
{
    int	c;
    int	n = 0;

    while( c = *ws++ ) {
	switch( c & 0x8080 ) {
	  case 0:
	  case 0x80:
	    if( as ) *as++ = c & 0xff;
	    n++;
	    break;
	  case 0x8000:
	  case 0x8080:
	    if( as ) {
		*as++ = c >> 8;
		*as++ = c & 0xff;
	    }
	    n += 2;
	    break;
	}
    }
    if( as ) *as = '\0';

    return n;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DefaultKanjiCode --
 *
 *	Determine the default Kanji code from current locale.
 *
 * Results:
 *	This procudure returns a kanji code to be used as a default.
 *
 * Side effects:
 *	None.
 *----------------------------------------------------------------------
 */

int
Tcl_DefaultKanjiCode()
{
    char *lang;
    int i;
    static struct lang {
	char *lang;
	int code;
    } langtab[] = {
	"ja_JP.SJIS",	TCL_SJIS,
	"ja_JP.EUC",	TCL_EUC,
	"ja_JP.JIS",	TCL_JIS,
	"ja_JP.mscode",	TCL_SJIS,	/* from Xsi nls database */
	"ja_JP.ujis",	TCL_EUC,	/* from Xsi nls database */
	"ja_JP",	TCL_EUC,	/* IBM */
	"Ja_JP",	TCL_SJIS,	/* IBM */
	"Jp_JP",	TCL_SJIS,	/* IBM */
	"japan",	TCL_EUC,	/* MIPS, NEC */
#ifdef hpux
	"japanese",	TCL_SJIS,	/* HP */
#else
	"japanese",	TCL_EUC,	/* SUN */
#endif
	"japanese.sjis",TCL_SJIS,	/* HP? */
	"japanese.euc",	TCL_EUC,	/* HP */
	"japanese-sjis",TCL_SJIS,	/* IBM */
	"japanese-ujis",TCL_EUC,	/* IBM */
	"C",		TCL_ANY,
	NULL,		0,
    };

#ifdef HAVE_SETLOCALE
    static int firstcall = 1;

    if (firstcall) {
	setlocale(LC_ALL, "");
	firstcall = 0;
    }

    lang = setlocale(LC_CTYPE, NULL);
#else /* HAVE_SETLOCALE */
    lang = getenv("LANG");
#endif /* HAVE_SETLOCALE */

    if (lang != NULL) {
	/*
	 * If the LANG variable is "C", skip some of the
	 * Kanji related feature (e.g. automatic encoding detection)
	 */
#ifdef C_LOCALE_SPECIAL
	if (!strcmp(lang, "C")) noKanjiFeature = 1;
#endif /* C_LOCALE_SPECIAL */
	for (i = 0; langtab[i].lang != NULL; i++) {
	    if (!strcmp(langtab[i].lang, lang)) {
		return langtab[i].code;
	    }
	}
    }
    return TCL_DEFAULT_KANJI_CODE;
}


/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiCode --
 *
 *	Returns the internal kanji code of the interpreter.
 *
 * Results:
 *	The internal kanji code.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiCode(interp)
     Tcl_Interp *interp;
{
    return ((Interp *)interp)->kanjiCode;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiStart --
 *
 *	Check if the string starts with kanji or not.
 *
 *	KanjiCodePtr is a pointer to an int which specifies
 *	the encoding of the given string.  This procedure
 *	checks if the first character of the string is a
 *	kanji.
 *
 *	If the value pointed by kanjiCodePtr is TCL_ANY,
 *	and if the first character of the string seems to be
 *	a kanji character, this procedure examines the string
 *	further, determines the encoding used, and assign the
 *	encoding value to *kanjiCodePtr.
 *
 * Results:
 *	If the first character of the given string is kanji,
 *	this procedure returns 1. Otherwise 0 is returned.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiStart(string, kanjiCodePtr)
     register unsigned char *string;
     register int *kanjiCodePtr;
{
    register unsigned char c = *string;

#ifdef C_LOCALE_SPECIAL
    if (noKanjiFeature) return 0;
#endif /* C_LOCALE_SPECIAL */
 retry:
    switch (*kanjiCodePtr) {
    case TCL_ANY:
	if (c != '\033' && c < 0x80) return 0;
	*kanjiCodePtr = EncodingDetection((Tcl_Interp *)NULL, string);
	goto retry;
    case TCL_JIS:
	return (c == '\033' && string[1] == '$' &&
		(string[2] == 'B' || string[2] == '@'));
    case TCL_SJIS:
	return ((0x81 <= c && c <= 0x9f) || (0xe0 <= c && c <= 0xfc));
    case TCL_EUC:
	return (c == 0x8e || c == 0x8f || (c & 0x80));
    default:	/* TCL_NOT_KANJI */
	return 0;
    }
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiEnd --
 *
 *	Check if the string ends with kanji or not.
 *
 *	KanjiCodePtr is a pointer to an int which specifies
 *	the encoding of the given string.  This procedure
 *	checks if the last character of the string is a
 *	kanji.
 *
 *	If the value pointed by kanjiCodePtr is TCL_ANY,
 *	and if the last character of the string seems to be
 *	a kanji character, this procedure examines the string
 *	further, determines the encoding used, and assign the
 *	encoding value to *kanjiCodePtr.
 *
 * Results:
 *	If the last character of the given string is kanji,
 *	this procedure returns 1. Otherwise 0 is returned.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiEnd(string, kanjiCodePtr)
     register unsigned char *string;
     register int *kanjiCodePtr;
{
    int len = strlen(string);
    unsigned char *p;
    int kanjiCode, result;

#ifdef C_LOCALE_SPECIAL
    if (noKanjiFeature) return 0;
#endif /* C_LOCALE_SPECIAL */

    switch (*kanjiCodePtr) {
    case TCL_ANY:
	while (*string != 0 && *string != '\033' && *string < 0x80) string++;
	break;
    case TCL_JIS:
	p = string + len;
	return (len > 3 && p[-3] == '\033' && p[-2] == '(' &&
		(p[-1] == 'J' || p[-1] == 'B'));
    case TCL_SJIS:
	while (len > 0 && string[--len] > 0x3F) ;
	string += len;
	while (*string != 0 && *string < 0x80) string++;
	break;
    case TCL_EUC:
	while (len > 0 && string[--len] > 0x7F) ;
	if (len > 0) string += (len + 1);
	break;
    default:	/* TCL_NOT_KANJI */
	return 0;
    }

    if ((len = strlen(string)) < 2) return 0;
    for (p = string; *p != 0; p++) {
	kanjiCode = *kanjiCodePtr;
	if ((result = Tcl_KanjiStart(p, &kanjiCode))) {
	    p += (Tcl_KanjiLength(p, kanjiCode) - 1);
	}
    }
    return result;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiLength --
 *
 *	Count a byte number of the given kanji sequence.
 *
 * Results:
 *	Return value is a byte number of the kanji sequence.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiLength(string, kanjiCode)
     register unsigned char *string;
     register int kanjiCode;
{
    register unsigned char c, *src = string;

    switch( kanjiCode ) {
      case TCL_JIS:
	while( c = *src++ ) {
	    if( c == '\033' && *src == '(' &&
	       (*(src+1) == 'J' || *(src+1) == 'B') ) {
		src += 3;
		break;
	    }
	}
	break;
      case TCL_SJIS:
	while( c = *src++ ) {
	    if( (c >= 0x81 && c <= 0x9f) || (c >= 0xe0 && c <= 0xfc) ) {
		src++;
	    } else {
		break;
	    }
	}
	break;
      case TCL_EUC:
	while( c = *src++ ) {
	    if( c == 0x8e ) {
		src++;
	    } else if( c == 0x8f ) {
		src += 2;
	    } else if( c & 0x80 ) {
		src++;
	    } else {
		break;
	    }
	}
	break;
    }

    return (int )(src - string - 1);
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiString --
 *
 *	Check if the string contains kanji.
 *
 * Results:
 *	If the string contains kanji, set its kanji code
 *	and return TCL_OK.  Otherwise return TCL_NOT_KANJI.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiString(interp, string, kanjiCodePtr)
     Tcl_Interp *interp;
     char *string;
     int *kanjiCodePtr;
{
    int encoding;

    if (
#ifdef C_LOCALE_SPECIAL
	noKanjiFeature ||
#endif /* C_LOCALE_SPECIAL */
	(encoding = EncodingDetection(interp, string)) == TCL_NOT_KANJI) {
	*kanjiCodePtr = TCL_ANY;
	return TCL_NOT_KANJI;
    } else {
	*kanjiCodePtr = encoding;
	return TCL_OK;
    }
}

/*
 *----------------------------------------------------------------------
 *
 * EncodingDetection --
 *
 *	Determine the encoding (kanji code) of the given string.
 *	This procedure assumes that the given string contains
 *	only ASCII and kanji (defined by the standard JIS X0208)
 *	characters. (i.e. no 1byte-kana and no user-defined
 *	characters are present)
 *
 *	The interp argument is used to retrieve the internal code
 *	of the interpreter, and the internal code is used to help
 *	determining the encoding when it is ambiguous.  Interp might
 *	be NULL.
 *
 * Results:
 *	The return value is the encoding (kanji code) of the
 *	given string.  If the string contains only ASCII
 *	characters, TCL_NOT_KANJI will be returned.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

static int
EncodingDetection(interp, string)
    Tcl_Interp *interp;
    char *string;
{
    unsigned char *s = (unsigned char *)string;
    int c;
    int kanji_found = 0;

    while ((c = *s++) != '\0') {
	if (c == '\033') {
	    /*
	     * It might be JIS encoding.  The valid JIS
	     * sequences are:
	     *    ESC $ B  ESC $ ( B   -- designate JIS X0208
	     *    ESC $ @  ESC $ ( @   -- designate old JIS X0208
	     *    ESC ( B              -- designate ASCII
	     *    ESC ( J              -- designate JIS X0201
	     */
	    if (((c = *s++) == '$' &&
		 (((c = *s++) == '(' && ((c = *s++) == 'B' || c == '@')) ||
		  (c == 'B' || c == '@'))) ||
		(c == '(' && ((c = *s++) == 'B' || c == 'J'))) {
		return TCL_JIS;
	    }
	} else if (c <= 0x80) {
	    /*
	     * ASCII character or 0x80 (which is not a
	     * valid EUC/SJIS/JIS character) -- skip it
	     */
	    continue;
	} else if (c < 0xa1) {
	    /* SJIS character */
	    return TCL_SJIS;
	} else if (c < 0xdf) {
	    /* EUC character */
	    return TCL_EUC;
	} else if (c <= 0xea) {
	    /* SJIS or EUC character -- ambiguous */
	    /* get the second byte */
	    if ((c = *s++) < 0xa1) {
		return TCL_SJIS;
	    } else if (c > 0xfc) {
		return TCL_EUC;
	    }
	    /*
	     * Still ambiguous.  Continue examining, and
	     * remember that kanji is found.
	     */
	    kanji_found = 1;
	} else if (c <= 0xf4) {
	    /* EUC character */
	    return TCL_EUC;
	    break;
	}
	if (c == '\0') break;
    }

    if (kanji_found) {
	/*
	 * The given string contains kanji character(s),
	 * but the encoding cannot be determined. It is
	 * either SJIS or EUC.  So we have to make a guess,
	 * based on the following hypothesis:
	 *
	 * a) It is likely that the encoding of the string
	 *    is the same as the internal encoding of the interpreter,
	 *    which is determined by the environmental variable $LANG.
	 * b) If above fails (ie the internal code is neither
	 *    SJIS nor EUC), it is likely that the encoding
	 *    is the same as TCL_DEFAULT_KANJI_CODE, which
	 *    is chosen by the installer at compilation time.
	 */
	int internalCode;

	if (interp != NULL &&
	    ((internalCode = Tcl_KanjiCode(interp)) == TCL_SJIS ||
	     internalCode == TCL_EUC)) {
	    return internalCode;
	} else if (TCL_DEFAULT_KANJI_CODE == TCL_SJIS ||
		   TCL_DEFAULT_KANJI_CODE == TCL_EUC) {
	    return TCL_DEFAULT_KANJI_CODE;
	}
	return TCL_EUC;		/* no luck. just a wild guess */
    }

    /* no kanji found */
    return TCL_NOT_KANJI;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_GetKanjiCode --
 *
 *	Get the kanji code according to the string.
 *
 * Results:
 *	A standard Tcl result.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_GetKanjiCode(interp, string, kanjiCodePtr)
     Tcl_Interp *interp;
     char *string;
     int *kanjiCodePtr;
{
    if( strcmp(string, "JIS") == 0 ) {
	*kanjiCodePtr = TCL_JIS;
    } else if( strcmp(string, "SJIS") == 0 ) {
	*kanjiCodePtr = TCL_SJIS;
    } else if( strcmp(string, "EUC") == 0 ) {
	*kanjiCodePtr = TCL_EUC;
    } else if( strcmp(string, "ANY") == 0 ) {
	*kanjiCodePtr = TCL_ANY;
    } else {
	Tcl_AppendResult(interp, "bad kanjiCode \"", string,
		"\": should be JIS, SJIS, EUC, or ANY", (char *) NULL);
	return TCL_ERROR;
    }

    return TCL_OK;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_KanjiFile --
 *
 *	Check if the file contains kanji.
 *
 * Results:
 *	If the string contains kanji, set its kanji code
 *	and return TCL_OK.  Otherwise return TCL_ERROR.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_KanjiFile(interp, fileName, kanjiCodePtr)
     Tcl_Interp *interp;
     char *fileName;
     int *kanjiCodePtr;
{
    Tcl_Channel chan;
    Tcl_DString ds, kc;
    int length, result = TCL_OK;

    chan = Tcl_OpenFileChannel(interp, fileName, "r", 0);
    if (chan == (Tcl_Channel) NULL) {
	return TCL_ERROR;
    }

    *kanjiCodePtr = TCL_ANY;
    Tcl_DStringInit(&ds);
    Tcl_DStringInit(&kc);
    (void) Tcl_GetChannelOption(chan, "-inputCode", &kc);
    (void) Tcl_SetChannelOption(interp, chan, "-inputCode", "ANY");
    while ((length = Tcl_Gets(chan, &ds)) > 0) {
	(void) Tcl_KanjiString(interp, Tcl_DStringValue(&ds), kanjiCodePtr);
	if (*kanjiCodePtr != TCL_ANY) {
	    break;
	}
    }
    (void) Tcl_SetChannelOption(interp, chan, "-inputCode", Tcl_DStringValue(&kc));
    Tcl_DStringFree(&ds);
    Tcl_DStringFree(&kc);

    if (length < 0) {
        if (!Tcl_Eof(chan) && !Tcl_InputBlocked(chan)) {
            Tcl_AppendResult(interp, "error reading \"",
		    Tcl_GetChannelName(chan), "\": ", Tcl_PosixError(interp),
		    (char *) NULL);
	    result = TCL_ERROR;
        }
    }

    if (Tcl_Close(interp, chan) != TCL_OK) {
	result = TCL_ERROR;
    }

    return result;
}

/*
 *--------------------------------------------------------------
 *
 * Tcl_WStrlen --
 *
 *	Get the length of the wide string.
 *
 * Results:
 *	Number of the wide characters.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

int
Tcl_WStrlen(wstr)
     wchar *wstr;
{
    int n = 0;

    while( *wstr++ ) n++;

    return n;
}

/*
 *--------------------------------------------------------------
 *
 * Tcl_WStrcpy --
 *
 *	Copy the wide string.
 *
 * Results:
 *	Pointer to the original string.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

wchar *
Tcl_WStrcpy(wstr1, wstr2)
     wchar *wstr1, *wstr2;
{
    wchar *ans = wstr1;

    while( *wstr1++ = *wstr2++ ) ;

    return( ans );
}

/*
 *--------------------------------------------------------------
 *
 * Tcl_WStrncpy --
 *
 *	Copy the specific number of wide characters.
 *
 * Results:
 *	Pointer to the original string.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

wchar *
Tcl_WStrncpy(wstr1, wstr2, n)
     wchar *wstr1, *wstr2;
     int n;
{
    wchar *ans = wstr1;

    while( n-- > 0 && (*wstr1++ = *wstr2++) ) ;

    while( n-- > 0 ) *wstr1++ = 0;

    return( ans );
}

/*
 *--------------------------------------------------------------
 *
 * Tcl_WStrcmp --
 *
 *	Compare two wide strings.
 *
 * Results:
 *	Return 0 if two strings are same.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

int
Tcl_WStrcmp(wstr1, wstr2)
     wchar *wstr1, *wstr2;
{
    while( *wstr1 && *wstr1 == *wstr2 ) wstr1++, wstr2++;

    return( *wstr1 - *wstr2 );
}

/*
 *--------------------------------------------------------------
 *
 * Tcl_WStrncmp --
 *
 *	Compare two wide strings.
 *
 * Results:
 *	Return 0 if two strings are same.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

int
Tcl_WStrncmp(wstr1, wstr2, n)
     wchar *wstr1, *wstr2;
     int n;
{
    while( n-- > 0 && *wstr1 && *wstr1 == *wstr2 ) wstr1++, wstr2++;

    if( n < 0 ) return( 0 );

    return( *wstr1 - *wstr2 );
}

/*
 *--------------------------------------------------------------
 *
 * Tcl_WStrstr --
 *
 *	Locate the first instance of a substring in a string.
 *
 * Results:
 *	If string contains substring, the return value is the
 *	location of the first matching instance of substring
 *	in string.  If string doesn't contain substring, the
 *	return value is 0.  Matching is done on an exact
 *	character-for-character basis with no wildcards or special
 *	characters.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

wchar *
Tcl_WStrstr(wstr, subwstr)
    register wchar *wstr;	/* String to search. */
    wchar *subwstr;		/* Substring to try to find in string. */
{
    register wchar *a, *b;

    /* First scan quickly through the two strings looking for a
     * single-character match.  When it's found, then compare the
     * rest of the substring.
     */

    b = subwstr;
    if (*b == 0) {
	return wstr;
    }
    for ( ; *wstr != 0; wstr += 1) {
	if (*wstr != *b) {
	    continue;
	}
	a = wstr;
	while (1) {
	    if (*b == 0) {
		return wstr;
	    }
	    if (*a++ != *b++) {
		break;
	    }
	}
	b = subwstr;
    }
    return (wchar *) 0;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_WStringMatch --
 *
 *	See if a particular wide string matches a particular pattern.
 *
 * Results:
 *	The return value is 1 if string matches pattern, and
 *	0 otherwise.  The matching operation permits the following
 *	special characters in the pattern: *?\[] (see the manual
 *	entry for details on what these mean).
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Tcl_WStringMatch(string, pattern)
    register wchar *string;	/* String. */
    register wchar *pattern;	/* Pattern, which may contain
				 * special characters. */
{
    wchar c2;

    while (1) {
	/* See if we're at the end of both the pattern and the string.
	 * If so, we succeeded.  If we're at the end of the pattern
	 * but not at the end of the string, we failed.
	 */
	
	if (*pattern == 0) {
	    if (*string == 0) {
		return 1;
	    } else {
		return 0;
	    }
	}
	if ((*string == 0) && (*pattern != '*')) {
	    return 0;
	}

	/* Check for a "*" as the next pattern character.  It matches
	 * any substring.  We handle this by calling ourselves
	 * recursively for each postfix of string, until either we
	 * match or we reach the end of the string.
	 */
	
	if (*pattern == '*') {
	    pattern += 1;
	    if (*pattern == 0) {
		return 1;
	    }
	    while (1) {
		if (Tcl_WStringMatch(string, pattern)) {
		    return 1;
		}
		if (*string == 0) {
		    return 0;
		}
		string += 1;
	    }
	}
    
	/* Check for a "?" as the next pattern character.  It matches
	 * any single character.
	 */

	if (*pattern == '?') {
	    goto thisCharOK;
	}

	/* Check for a "[" as the next pattern character.  It is followed
	 * by a list of characters that are acceptable, or by a range
	 * (two characters separated by "-").
	 */
	
	if (*pattern == '[') {
	    pattern += 1;
	    while (1) {
		if ((*pattern == ']') || (*pattern == 0)) {
		    return 0;
		}
		if (*pattern == *string) {
		    break;
		}
		if (pattern[1] == '-') {
		    c2 = pattern[2];
		    if (c2 == 0) {
			return 0;
		    }
		    if ((*pattern <= *string) && (c2 >= *string)) {
			break;
		    }
		    if ((*pattern >= *string) && (c2 <= *string)) {
			break;
		    }
		    pattern += 2;
		}
		pattern += 1;
	    }
	    while ((*pattern != ']') && (*pattern != 0)) {
		pattern += 1;
	    }
	    goto thisCharOK;
	}
    
	/* If the next pattern character is '/', just strip off the '/'
	 * so we do exact matching on the character that follows.
	 */
	
	if (*pattern == '\\') {
	    pattern += 1;
	    if (*pattern == 0) {
		return 0;
	    }
	}

	/* There's no special character.  Just make sure that the next
	 * characters of each string match.
	 */
	
	if (*pattern != *string) {
	    return 0;
	}

	thisCharOK: pattern += 1;
	string += 1;
    }
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DWStringInit --
 *
 *	Initializes a dynamic string, discarding any previous contents
 *	of the string (Tcl_DWStringFree should have been called already
 *	if the dynamic string was previously in use).
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The dynamic string is initialized to be empty.
 *
 *----------------------------------------------------------------------
 */

void
Tcl_DWStringInit(dwsPtr)
    register Tcl_DWString *dwsPtr;	/* Pointer to structure for
					 * dynamic string. */
{
    dwsPtr->wstring = dwsPtr->staticSpace;
    dwsPtr->length = 0;
    dwsPtr->spaceAvl = TCL_DWSTRING_STATIC_SIZE;
    dwsPtr->staticSpace[0] = 0;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DWStringAppend --
 *
 *	Append more characters to the current value of a dynamic string.
 *
 * Results:
 *	The return value is a pointer to the dynamic string's new value.
 *
 * Side effects:
 *	Length bytes from string (or all of string if length is less
 *	than zero) are added to the current value of the string.  Memory
 *	gets reallocated if needed to accomodate the string's new size.
 *
 *----------------------------------------------------------------------
 */

wchar *
Tcl_DWStringAppend(dwsPtr, wstring, length)
    register Tcl_DWString *dwsPtr;	/* Structure describing dynamic
					 * string. */
    wchar *wstring;			/* String to append.  If length is
					 * -1 then this must be
					 * null-terminated. */
    int length;				/* Number of characters from string
					 * to append.  If < 0, then append all
					 * of string, up to null at end. */
{
    int newSize;
    wchar *newString, *dst, *end;

    if (length < 0) {
	length = Tcl_WStrlen(wstring);
    }
    newSize = length + dwsPtr->length;

    /*
     * Allocate a larger buffer for the string if the current one isn't
     * large enough.  Allocate extra space in the new buffer so that there
     * will be room to grow before we have to allocate again.
     */

    if (newSize >= dwsPtr->spaceAvl) {
	dwsPtr->spaceAvl = newSize*2;
	newString = (wchar *) ckalloc((unsigned) (dwsPtr->spaceAvl * sizeof(wchar)));
	memcpy((VOID *)newString, (VOID *) dwsPtr->wstring,
		(size_t) (dwsPtr->length * sizeof(wchar)));
	if (dwsPtr->wstring != dwsPtr->staticSpace) {
	    ckfree((char *) dwsPtr->wstring);
	}
	dwsPtr->wstring = newString;
    }

    /*
     * Copy the new string into the buffer at the end of the old
     * one.
     */

    for (dst = dwsPtr->wstring + dwsPtr->length, end = wstring+length;
	    wstring < end; wstring++, dst++) {
	*dst = *wstring;
    }
    *dst = 0;
    dwsPtr->length += length;
    return dwsPtr->wstring;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DWStringSetLength --
 *
 *	Change the length of a dynamic string.  This can cause the
 *	string to either grow or shrink, depending on the value of
 *	length.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The length of dsPtr is changed to length and a null byte is
 *	stored at that position in the string.  If length is larger
 *	than the space allocated for dsPtr, then a panic occurs.
 *
 *----------------------------------------------------------------------
 */

void
Tcl_DWStringSetLength(dwsPtr, length)
    register Tcl_DWString *dwsPtr;	/* Structure describing dynamic
					 * string. */
    int length;				/* New length for dynamic string. */
{
    if (length < 0) {
	length = 0;
    }
    if (length >= dwsPtr->spaceAvl) {
	wchar *newString;

	dwsPtr->spaceAvl = length+1;
	newString = (wchar *) ckalloc((unsigned) (dwsPtr->spaceAvl * sizeof(wchar)));

	/*
	 * SPECIAL NOTE: must use memcpy, not strcpy, to copy the string
	 * to a larger buffer, since there may be embedded NULLs in the
	 * string in some cases.
	 */

	memcpy((VOID *) newString, (VOID *) dwsPtr->wstring,
		(size_t) (dwsPtr->length * sizeof(wchar)));
	if (dwsPtr->wstring != dwsPtr->staticSpace) {
	    ckfree((char *) dwsPtr->wstring);
	}
	dwsPtr->wstring = newString;
    }
    dwsPtr->length = length;
    dwsPtr->wstring[length] = 0;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DWStringFree --
 *
 *	Frees up any memory allocated for the dynamic string and
 *	reinitializes the string to an empty state.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The previous contents of the dynamic string are lost, and
 *	the new value is an empty string.
 *
 *----------------------------------------------------------------------
 */

void
Tcl_DWStringFree(dwsPtr)
    register Tcl_DWString *dwsPtr;	/* Structure describing dynamic
					 * string. */
{
    if (dwsPtr->wstring != dwsPtr->staticSpace) {
	ckfree((char *) dwsPtr->wstring);
    }
    dwsPtr->wstring = dwsPtr->staticSpace;
    dwsPtr->length = 0;
    dwsPtr->spaceAvl = TCL_DWSTRING_STATIC_SIZE;
    dwsPtr->staticSpace[0] = 0;
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DWStringResult --
 *
 *	This procedure moves the value of a dynamic string into an
 *	interpreter as its result.  The string itself is reinitialized
 *	to an empty string.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The string is "moved" to interp's result, and any existing
 *	result for interp is freed up.  DsPtr is reinitialized to
 *	an empty string.
 *
 *----------------------------------------------------------------------
 */

void
Tcl_DWStringResult(interp, dwsPtr)
    Tcl_Interp *interp;			/* Interpreter whose result is to be
					 * reset. */
    Tcl_DWString *dwsPtr;		/* Dynamic string that is to become
					 * the result of interp. */
{
    int kanjiCode = ((Interp *) interp)->kanjiCode;
    int length;
    char* string;

    length = Tcl_KanjiDecode(kanjiCode, dwsPtr->wstring, NULL);
    string = (char *) ckalloc((unsigned) (length + 1));
    (void) Tcl_KanjiDecode(kanjiCode, dwsPtr->wstring, string);

    Tcl_ResetResult(interp);
    interp->result = string;
    interp->freeProc = (Tcl_FreeProc *) free;

    Tcl_DWStringFree(dwsPtr);
}

/*
 *----------------------------------------------------------------------
 *
 * Tcl_DWStringGetResult --
 *
 *	This procedure moves the result of an interpreter into a
 *	dynamic string.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The interpreter's result is cleared, and the previous contents
 *	of dsPtr are freed.
 *
 *----------------------------------------------------------------------
 */

void
Tcl_DWStringGetResult(interp, dwsPtr)
    Tcl_Interp *interp;			/* Interpreter whose result is to be
					 * reset. */
    Tcl_DWString *dwsPtr;		/* Dynamic string that is to become
					 * the result of interp. */
{
    Interp *iPtr = (Interp *) interp;
    int kanjiCode = iPtr->kanjiCode;
    int length;
    wchar *wstring;

    length = Tcl_KanjiEncode(kanjiCode, iPtr->result, NULL);
    wstring = (wchar *) ckalloc((unsigned) (length * sizeof(wchar)));
    (void) Tcl_KanjiEncode(kanjiCode, iPtr->result, wstring);

    if (iPtr->freeProc != NULL) {
	(*iPtr->freeProc)(iPtr->result);
	iPtr->freeProc = NULL;
    }
    iPtr->result = iPtr->resultSpace;
    iPtr->resultSpace[0] = 0;

    if (dwsPtr->wstring != dwsPtr->staticSpace) {
	ckfree((char *) dwsPtr->wstring);
    }
    dwsPtr->length = Tcl_WStrlen(wstring);
    if (dwsPtr->length < TCL_DWSTRING_STATIC_SIZE) {
	dwsPtr->wstring = dwsPtr->staticSpace;
	dwsPtr->spaceAvl = TCL_DWSTRING_STATIC_SIZE;
	Tcl_WStrcpy(dwsPtr->wstring, wstring);
	ckfree((char *) wstring);
    } else {
	dwsPtr->wstring = wstring;
	dwsPtr->spaceAvl = dwsPtr->length + 1;
    }
}
#endif /* KANJI */
