#! /bin/sh
echo "all"
(cd all;gen.sh ../data/index)
